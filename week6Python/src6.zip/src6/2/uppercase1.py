# Uppercases string all at once

from cs50 import get_string

s = get_string("Before: ")
print(f"After:  {s.upper()}")
