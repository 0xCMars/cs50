# Integer non-overflow

# Iteratively double i
i = 1
while True:
    print(i)
    i *= 2
