# Better design

for i in range(3):
    print("meow")
