# Averages three numbers using a list

# Scores
scores = [72, 73, 33]

# Print average
print(f"Average: {sum(scores) / len(scores)}")
